package view;

import java.awt.Desktop;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.draw.DottedLine;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.property.UnitValue;
import com.itextpdf.layout.element.LineSeparator;

import database.MyDatabase;
import model.OrderItem;

public class ViewPurchase extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private List<OrderItem> cartItems;
    private String loggedInUserName;

    public ViewPurchase(List<OrderItem> cartItems, String loggedInUserName) throws ClassNotFoundException {
    	this.cartItems = cartItems;
        this.loggedInUserName = loggedInUserName;
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 501, 345);
        contentPane = new JPanel();
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // Retrieve the latest orderID
        int latestOrderID = fetchLatestOrderID();

        // Now, you can use this latestOrderID to fetch and display the order details
        String[] orderDetails = retrieveOrderDetails(latestOrderID);

        // Display order details using JLabels
        JLabel lblName = new JLabel("Name: " + orderDetails[0]);
        lblName.setBounds(10, 10, 200, 20);
        contentPane.add(lblName);

        JLabel lblTotalPayment = new JLabel("Total Payment: RM" + orderDetails[1] +"0");
        lblTotalPayment.setBounds(10, 40, 200, 20);
        contentPane.add(lblTotalPayment);

        JLabel lblPoints = new JLabel("Points Obtained: " + orderDetails[2]);
        lblPoints.setBounds(10, 70, 200, 20);
        contentPane.add(lblPoints);

        JLabel lblPaymentMethod = new JLabel("Payment Method:");
        lblPaymentMethod.setBounds(10, 200, 150, 20);
        contentPane.add(lblPaymentMethod);

        JButton btnCash = new JButton("Cash");
        btnCash.setBounds(170, 200, 80, 20);
        btnCash.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                generateReceipt(cartItems, orderDetails);
                JOptionPane.showMessageDialog(contentPane, "Payment Method: Cash");
                MainMenu frame = new MainMenu(loggedInUserName);
                frame.launch(loggedInUserName);
                frame.setVisible(true);
                dispose();
            }
        });
        contentPane.add(btnCash);

        JButton btnOnlinePayment = new JButton("Online Payment");
        btnOnlinePayment.setBounds(260, 200, 150, 20);
        btnOnlinePayment.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
            	try {
            		OnlinePayment onlinePaymentFrame = new OnlinePayment(cartItems);
            		onlinePaymentFrame.launch(loggedInUserName); // Pass the loggedInUserName
            		onlinePaymentFrame.setVisible(true);
            		dispose();
                    dispose();
                } catch (ClassNotFoundException e1) {
                	  e1.printStackTrace(); // Handle the exception appropriately
                }
            }
        });
        contentPane.add(btnOnlinePayment);
    }

    private int fetchLatestOrderID() throws ClassNotFoundException {
        int latestOrderID = 0;

        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT MAX(orderID) FROM orderlist";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    latestOrderID = resultSet.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return latestOrderID;
    }

    private String[] retrieveOrderDetails(int orderID) throws ClassNotFoundException {
        String[] orderDetails = new String[3];

        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT name, totalPayment, points FROM orderlist WHERE orderID = ?";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
                preparedStatement.setInt(1, orderID);
                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    orderDetails[0] = resultSet.getString("name");
                    orderDetails[1] = String.valueOf(resultSet.getDouble("totalPayment"));
                    orderDetails[2] = String.valueOf(resultSet.getInt("points"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderDetails;
    }
    
    public void generateReceipt (List<OrderItem> orderItems, String[] orderDetails) {
        try {
            // Initialize PDF writer
            PdfWriter writer = new PdfWriter("Receipt.pdf");

            // Initialize PDF document
            PdfDocument pdf = new PdfDocument(writer);

            // Initialize document
            Document document = new Document(pdf);
            
            // Updated title and address
            document.add(new Paragraph("Coffee Shop").setFontSize(20).setTextAlignment(TextAlignment.CENTER));
            document.add(new Paragraph("Spread the cheer, have a cup here").setFontSize(12).setTextAlignment(TextAlignment.CENTER));
            
            // Updated city index and telephone number
            document.add(new Paragraph("Lot 1, Bangunan Melaka, 75100 Bandaraya Melaka, Melaka").setFontSize(12).setTextAlignment(TextAlignment.CENTER));
            document.add(new Paragraph("Tel: 011-1285 0115 (Customer Service)").setFontSize(12).setTextAlignment(TextAlignment.CENTER));
            
            document.add(new LineSeparator(new DottedLine()));
                        
            // Store number and current date & time
            document.add(new Paragraph("Store: 1").setFontSize(12));
            document.add(new Paragraph("Date & Time: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm"))).setFontSize(12));
            
            // Random survey number
            Random rand = new Random();
            int surveyNumber = rand.nextInt((999999 - 100000) + 1) + 100000;
            document.add(new Paragraph("Survey code: " + surveyNumber).setFontSize(12));
            
            // Create a float array for column widths
            float[] columnWidths = {3, 2, 2};  // Adjust these values as needed

            // Create a UnitValue array
            UnitValue[] unitValues = UnitValue.createPercentArray(columnWidths);

            // Create the table with the UnitValue array
            Table table = new Table(unitValues);

            // Add column headers
            table.addCell("Drink");
            table.addCell("Quantity");
            table.addCell("Subtotal");

            // Add rows for each item in the order
            for (OrderItem item : orderItems) {
                table.addCell(item.getDrinkName());
                table.addCell(String.valueOf(item.getQuantity()));
                table.addCell(String.valueOf(item.getTotalPayment()));
            }

            // Add the table to the document
            document.add(table);

            document.add(new Paragraph("Payment Type: Cash"));
            // Add customer name, points obtained, and total payment
            document.add(new Paragraph("Customer: " + orderDetails[0]));
            document.add(new Paragraph("Points Obtained: " + orderDetails[2]));
            document.add(new Paragraph("Total Payment: RM" + orderDetails[1] +"0"));

            document.add(new LineSeparator(new DottedLine()));
            
            document.add(new Paragraph("Thank you for coming to our shop!").setFontSize(12).setTextAlignment(TextAlignment.CENTER));

            // Close the document
            document.close();

            // Open the PDF
            if (Desktop.isDesktopSupported()) {
                try {
                    File myFile = new File("Receipt.pdf");
                    Desktop.getDesktop().open(myFile);
                } catch (IOException ex) {
                    // no application registered for PDFs
                    ex.printStackTrace();
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}