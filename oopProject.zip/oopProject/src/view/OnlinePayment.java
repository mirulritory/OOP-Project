package view;

import java.awt.Desktop;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.draw.DottedLine;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.LineSeparator;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.property.UnitValue;

import database.MyDatabase;
import model.OrderItem;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Random;
import java.awt.event.ActionEvent;

public class OnlinePayment extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JTextField textField_1;
    private List<OrderItem> cartItems;
    private String loggedInUserName;

    public OnlinePayment(List<OrderItem> cartItems) throws ClassNotFoundException {

        this.cartItems = cartItems;
    	// Retrieve the latest orderID
        int latestOrderID = fetchLatestOrderID();

        // Now, you can use this latestOrderID to fetch and display the order details
        String[] orderDetails = retrieveOrderDetails(latestOrderID);
        
        setTitle("Online Payment");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        
        // Initialize contentPane
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblBank = new JLabel("Choose your bank:");
        lblBank.setFont(new Font("Tahoma", Font.PLAIN, 25));
        lblBank.setBounds(10, 16, 205, 31);
        contentPane.add(lblBank);

        JComboBox<String> comboBoxBank = new JComboBox<>();
        comboBoxBank.setFont(new Font("Tahoma", Font.PLAIN, 25));
        comboBoxBank.setModel(new DefaultComboBoxModel(new String[] {"RHB Bank", "CIMB", "BSN", "Touch N Go"}));
        comboBoxBank.setBounds(225, 13, 173, 37);
        contentPane.add(comboBoxBank);
        
        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 25));
        lblUsername.setBounds(10, 55, 118, 31);
        contentPane.add(lblUsername);
        
        textField = new JTextField();
        textField.setFont(new Font("Tahoma", Font.PLAIN, 10));
        textField.setBounds(138, 61, 96, 19);
        contentPane.add(textField);
        textField.setColumns(10);
        
        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 25));
        lblPassword.setBounds(10, 96, 112, 31);
        contentPane.add(lblPassword);
        
        textField_1 = new JTextField();
        textField_1.setFont(new Font("Tahoma", Font.PLAIN, 10));
        textField_1.setColumns(10);
        textField_1.setBounds(138, 102, 96, 19);
        contentPane.add(textField_1);
        
        JButton btnConfirm = new JButton("Confirm");
        btnConfirm.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		int response = JOptionPane.showConfirmDialog(null, "Do you want to proceed?", "Confirm",
        			    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        			if (response == JOptionPane.NO_OPTION) {
        			  System.out.println("No button clicked");
        			} else if (response == JOptionPane.YES_OPTION) {
        				generateReceipt(cartItems, orderDetails);
                        MainMenu frame = new MainMenu(loggedInUserName);
                        frame.launch(loggedInUserName);
                        frame.setVisible(true);
        				dispose();
        			} else if (response == JOptionPane.CLOSED_OPTION) {
        			  System.out.println("JOptionPane closed");
        			}

        	}
        });
        btnConfirm.setBounds(138, 131, 96, 21);
        contentPane.add(btnConfirm);
        
        // Set the frame visible
        setVisible(true);
    }
    
    public void generateReceipt (List<OrderItem> orderItems, String[] orderDetails) {
        try {
            // Initialize PDF writer
            PdfWriter writer = new PdfWriter("Receipt.pdf");

            // Initialize PDF document
            PdfDocument pdf = new PdfDocument(writer);

            // Initialize document
            Document document = new Document(pdf);
            
            // Updated title and address
            document.add(new Paragraph("Coffee Shop").setFontSize(20).setTextAlignment(TextAlignment.CENTER));
            document.add(new Paragraph("Spread the cheer, have a cup here").setFontSize(12).setTextAlignment(TextAlignment.CENTER));
            
            // Updated city index and telephone number
            document.add(new Paragraph("Lot 1, Bangunan Melaka, 75100 Bandaraya Melaka, Melaka").setFontSize(12).setTextAlignment(TextAlignment.CENTER));
            document.add(new Paragraph("Tel: 011-1285 0115 (Customer Service)").setFontSize(12).setTextAlignment(TextAlignment.CENTER));
            
            document.add(new LineSeparator(new DottedLine()));
                        
            // Store number and current date & time
            document.add(new Paragraph("Store: 1").setFontSize(12));
            document.add(new Paragraph("Date & Time: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm"))).setFontSize(12));
            
            // Random survey number
            Random rand = new Random();
            int surveyNumber = rand.nextInt((999999 - 100000) + 1) + 100000;
            document.add(new Paragraph("Survey code: " + surveyNumber).setFontSize(12));
            
            // Create a float array for column widths
            float[] columnWidths = {3, 2, 2};  // Adjust these values as needed

            // Create a UnitValue array
            UnitValue[] unitValues = UnitValue.createPercentArray(columnWidths);

            // Create the table with the UnitValue array
            Table table = new Table(unitValues);

            // Add column headers
            table.addCell("Drink");
            table.addCell("Quantity");
            table.addCell("Subtotal");

            // Add rows for each item in the order
            for (OrderItem item : orderItems) {
                table.addCell(item.getDrinkName());
                table.addCell(String.valueOf(item.getQuantity()));
                table.addCell(String.valueOf(item.getTotalPayment()));
            }

            // Add the table to the document
            document.add(table);
            
            document.add(new Paragraph("Payment Type: Online Payment"));
            // Add customer name, points obtained, and total payment
            document.add(new Paragraph("Customer: " + orderDetails[0]));
            document.add(new Paragraph("Points Obtained: " + orderDetails[2]));
            document.add(new Paragraph("Total Payment: RM" + orderDetails[1] +"0"));

            document.add(new LineSeparator(new DottedLine()));
            
            document.add(new Paragraph("Thank you for coming to our shop!").setFontSize(12).setTextAlignment(TextAlignment.CENTER));

            // Close the document
            document.close();

            // Open the PDF
            if (Desktop.isDesktopSupported()) {
                try {
                    File myFile = new File("Receipt.pdf");
                    Desktop.getDesktop().open(myFile);
                } catch (IOException ex) {
                    // no application registered for PDFs
                    ex.printStackTrace();
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private String[] retrieveOrderDetails(int orderID) throws ClassNotFoundException {
        String[] orderDetails = new String[3];

        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT name, totalPayment, points FROM orderlist WHERE orderID = ?";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
                preparedStatement.setInt(1, orderID);
                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    orderDetails[0] = resultSet.getString("name");
                    orderDetails[1] = String.valueOf(resultSet.getDouble("totalPayment"));
                    orderDetails[2] = String.valueOf(resultSet.getInt("points"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderDetails;
    }
    
    private int fetchLatestOrderID() throws ClassNotFoundException {
        int latestOrderID = 0;

        try (Connection conn = MyDatabase.doConnection()) {
            String sql = "SELECT MAX(orderID) FROM orderlist";
            try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    latestOrderID = resultSet.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return latestOrderID;
    }

    public void launch(String loggedInUserName) {
        this.loggedInUserName = loggedInUserName;
    }
}
