package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.chart.labels.PieSectionLabelGenerator;

import model.OrderItem;

import java.awt.Component;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;

public class GenerateReport extends JFrame {

	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GenerateReport frame = new GenerateReport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public GenerateReport() {
		setTitle("Generate Report");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JButton btnTopDrinks = new JButton("Drink Sales");
		btnTopDrinks.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Fetch drink sales data from the database
		        List<OrderItem> drinkSalesDataList = fetchDrinkSalesData();

		        // Create and display the pie chart
		        JFreeChart chart = createDrinkSalesPieChart(drinkSalesDataList);
		        ChartPanel chartPanel = new ChartPanel(chart);
		        chartPanel.setPreferredSize(new java.awt.Dimension(560, 370));

		        JFrame chartFrame = new JFrame("Drink Sales Pie Chart");
		        chartFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		        chartFrame.getContentPane().add(chartPanel);
		        chartFrame.pack();
		        chartFrame.setLocationRelativeTo(null);
		        chartFrame.setVisible(true);
		    }
		});

		btnTopDrinks.setBounds(148, 45, 120, 52);
		getContentPane().add(btnTopDrinks);
		
		JButton btnBack = new JButton("Back");
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Navigate back to the StaffMenu
                StaffMenu staffMenu = new StaffMenu();
                staffMenu.setVisible(true);
                dispose();
            }
        });		btnBack.setBounds(148, 107, 120, 52);
		getContentPane().add(btnBack);
	}
	
	private List<OrderItem> fetchDrinkSalesData() {
        List<OrderItem> drinkSalesDataList = new ArrayList<>();

        // Database connection details
        String url = "jdbc:mysql://localhost:3306/myoop";
        String username = "root";
        String password = "";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String query = "SELECT drinkName, SUM(quantity) AS totalQuantity FROM orderitem GROUP BY drinkName";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String drinkName = resultSet.getString("drinkName");
                        int totalQuantity = resultSet.getInt("totalQuantity");
                        double drinkPrice = getDrinkPriceFromDatabase(drinkName); // You need to implement this method

                        OrderItem orderItem = new OrderItem(drinkName, totalQuantity, drinkPrice);
                        drinkSalesDataList.add(orderItem);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return drinkSalesDataList;
    }
	
	private double getDrinkPriceFromDatabase(String drinkName) {
	    // Database connection details
	    String url = "jdbc:mysql://localhost:3306/myoop";
	    String username = "root";
	    String password = "";

	    // SQL query to retrieve the drink price based on drinkName
	    String query = "SELECT drinkPrice FROM beveragesmenu WHERE drinkName = ?";

	    try (Connection connection = DriverManager.getConnection(url, username, password);
	         PreparedStatement preparedStatement = connection.prepareStatement(query)) {

	        // Set the parameter in the prepared statement
	        preparedStatement.setString(1, drinkName);

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                // Retrieve and return the drink price from the result set
	                return resultSet.getDouble("drinkPrice");
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        // Handle the exception or log the error
	    }

	    // Return a default value or handle the case where the drink price is not found
	    return 0.0;
	}
	
	private JFreeChart createDrinkSalesPieChart(List<OrderItem> drinkSalesDataList) {
	    DefaultPieDataset dataset = new DefaultPieDataset();

	    int totalQuantity = drinkSalesDataList.stream().mapToInt(OrderItem::getQuantity).sum();

	    for (OrderItem data : drinkSalesDataList) {
	        double percentage = ((double) data.getQuantity() / totalQuantity) * 100.0;
	        dataset.setValue(data.getDrinkName(), data.getQuantity());
	    }

	    JFreeChart chart = ChartFactory.createPieChart(
	            "Drink Sales",    // Chart title
	            dataset,          // Dataset
	            true,             // Include legend
	            true,
	            false);

	    // Get the plot from the chart and set the label generator
	    PiePlot plot = (PiePlot) chart.getPlot();

	    // Use the correct constructor for StandardPieSectionLabelGenerator
	    PieSectionLabelGenerator labelGenerator = new StandardPieSectionLabelGenerator("{0} ({2})", new java.text.DecimalFormat("0"), new java.text.DecimalFormat("0.0%"));
	    plot.setLabelGenerator(labelGenerator);

	    return chart;
	}
}