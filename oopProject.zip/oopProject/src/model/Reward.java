package model;

public class Reward {
	private int rewardID;
	private String rewardName;
	private int pointN;
	public int getRewardID() {
		return rewardID;
	}
	public void setRewardID(int rewardID) {
		this.rewardID = rewardID;
	}
	public String getRewardName() {
		return rewardName;
	}
	public void setRewardName(String rewardName) {
		this.rewardName = rewardName;
	}
	public int getPointN() {
		return pointN;
	}
	public void setPointN(int pointN) {
		this.pointN = pointN;
	}
	
	

}
